import React from 'react'
import Appointment from '../components/Appointment';
const Appointment = () => {
  return (
    <div>
      <Appointment/>
    </div>
  )
}

export default Appointment
