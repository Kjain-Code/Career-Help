import React from 'react'
import Counsellor from '../components/Counsellor/Counsellor'

const Councellor = () => {
  return (
    <div>
      <Counsellor/>
    </div>
  )
}

export default Councellor
